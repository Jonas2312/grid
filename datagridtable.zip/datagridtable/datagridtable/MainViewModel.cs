﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace datagridtable
{
    public class ABC
    {
        public bool abc { get; set; }
        public string ggg { get; set; }
    }
    public class MainViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        public object[][] _array;
        public object[][] Array 
        { 
            get => _array; 
            set
            {
                _array = value;
                OnPropertyChanged();
            }
        }

        public string _rows;
        public string Rows 
        { 
            get => _rows;
            set
            {
                _rows = value; 
                var array = new object[Int32.Parse(_rows)][];
                for (int i = 0; i < Int32.Parse(_rows); i++)
                {
                    array[i] = new object[Int32.Parse(_columns)];
                }
                Array = array;
                OnPropertyChanged();
            }
        }

        public string _columns;
        public string Columns 
        { 
            get => _columns;
            set
            {
                _columns = value;
                var array = new object[Int32.Parse(_rows)][];
                for(int i = 0; i < Int32.Parse(_rows); i++)
                {
                    array[i] = new object[Int32.Parse(_columns)];
                }
                Array = array;
                OnPropertyChanged();
            }
        }

        public MainViewModel()
        {
            _columns = "5";
            Rows = "5";
        }

        
    }
}
